// CLIBridge - Central CLI data distribution system
function CLIBridge() {
  try {
    const [connections, setConnections] = React.useState({
      srsran: { status: 'connected', parser: null },
      open5gs: { status: 'connected', parser: null },
      kamailio: { status: 'connected', parser: null }
    });

    const [dataFlows, setDataFlows] = React.useState({
      rawLogs: [],
      parsedLogs: [],
      metrics: {
        srsran: { throughput: 125.5, latency: 12.3, snr: 18.2, rsrp: -85 },
        open5gs: { sessionCount: 42, registrations: 156, pduSessions: 38 },
        kamailio: { sipCalls: 23, registrations: 89, responses: 234 }
      },
      callFlows: [
        { id: 1, timestamp: new Date().toISOString(), source: 'UE', target: 'IMS', message: 'REGISTER', component: 'SIP' },
        { id: 2, timestamp: new Date().toISOString(), source: 'UE', target: 'AMF', message: 'Registration Request', component: 'NAS' }
      ],
      layerStats: {
        srsran: { totalMessages: 1250, errorCount: 12, warnCount: 45, phyMessages: 890, macMessages: 360 },
        open5gs: { totalMessages: 890, errorCount: 3, warnCount: 18, amfMessages: 340, smfMessages: 280 },
        kamailio: { totalMessages: 456, errorCount: 8, warnCount: 22, sipRequests: 200, sipResponses: 256 }
      },
      protocolData: {
        phy: { cellId: 1, frequency: 3500, bandwidth: 100, txPower: 23 },
        mac: { rnti: '0x4601', harqProcesses: 8, schedulingGrants: 145 },
        rrc: { connections: 12, handovers: 3, measurements: 89 },
        nas: { attachedUes: 42, tauRequests: 15, bearers: 67 },
        ims: { registeredUsers: 38, activeCalls: 12, sipSessions: 45 }
      }
    });

    // Initialize parsers
    React.useEffect(() => {
      try {
        setConnections(prev => ({
          ...prev,
          srsran: { ...prev.srsran, parser: window.SrsranLogParser ? window.SrsranLogParser() : null },
          open5gs: { ...prev.open5gs, parser: window.Open5gsCliParser ? window.Open5gsCliParser() : null },
          kamailio: { ...prev.kamailio, parser: window.KamailioCliParser ? window.KamailioCliParser() : null }
        }));

        // Simulate real-time data updates
        const interval = setInterval(() => {
          simulateNewData();
        }, 3000);

        return () => clearInterval(interval);
      } catch (error) {
        console.error('CLIBridge init error:', error);
      }
    }, []);

    const simulateNewData = () => {
      try {
        const sources = ['srsran', 'open5gs', 'kamailio'];
        const source = sources[Math.floor(Math.random() * sources.length)];
        
        const mockLogEntry = {
          id: Date.now() + Math.random(),
          timestamp: new Date().toISOString(),
          source,
          component: getRandomComponent(source),
          level: ['info', 'warn', 'error'][Math.floor(Math.random() * 3)],
          message: generateMockMessage(source),
          fields: {}
        };

        setDataFlows(prev => ({
          ...prev,
          rawLogs: [...prev.rawLogs.slice(-199), mockLogEntry],
          parsedLogs: [...prev.parsedLogs.slice(-199), mockLogEntry]
        }));
      } catch (error) {
        console.error('Simulate data error:', error);
      }
    };

    const getRandomComponent = (source) => {
      const components = {
        srsran: ['PHY', 'MAC', 'RLC', 'PDCP', 'RRC'],
        open5gs: ['AMF', 'SMF', 'UPF', 'AUSF', 'UDM'],
        kamailio: ['IMS', 'SIP']
      };
      const sourceComponents = components[source] || ['UNKNOWN'];
      return sourceComponents[Math.floor(Math.random() * sourceComponents.length)];
    };

    const generateMockMessage = (source) => {
      const messages = {
        srsran: [
          'Cell search completed successfully',
          'UE connected with RNTI 0x4601',
          'Throughput: 125.5 Mbps, SNR: 18.2 dB',
          'RRC Connection Setup Complete'
        ],
        open5gs: [
          'Registration accepted for SUPI 001010123456789',
          'PDU Session established ID: 5',
          'Authentication successful',
          'SMF context created'
        ],
        kamailio: [
          'SIP REGISTER from 192.168.1.100',
          'INVITE processing for call-id abc123',
          '200 OK response sent',
          'User authenticated successfully'
        ]
      };
      const sourceMessages = messages[source] || ['Unknown message'];
      return sourceMessages[Math.floor(Math.random() * sourceMessages.length)];
    };

    return {
      connections,
      dataFlows,
      processCliData: (data, source) => simulateNewData(),
      connect: (source) => {
        setConnections(prev => ({
          ...prev,
          [source]: { ...prev[source], status: 'connected' }
        }));
      },
      disconnect: (source) => {
        setConnections(prev => ({
          ...prev,
          [source]: { ...prev[source], status: 'disconnected' }
        }));
      },
      getStatus: (source) => connections[source]?.status || 'disconnected',
      getMetricsFor: (component) => dataFlows.metrics,
      getProtocolData: (layer) => dataFlows.protocolData[layer] || {},
      getLayerStats: (layer) => dataFlows.layerStats
    };

  } catch (error) {
    console.error('CLIBridge error:', error);
    return { 
      connections: {}, 
      dataFlows: { rawLogs: [], metrics: {}, callFlows: [], layerStats: {} },
      getMetricsFor: () => ({}),
      getProtocolData: () => ({}),
      getLayerStats: () => ({})
    };
  }
}

window.CLIBridge = CLIBridge;
