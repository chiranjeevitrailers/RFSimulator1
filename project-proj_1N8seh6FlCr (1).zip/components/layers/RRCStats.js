// RRCStats Component
function RRCStats({ logs, stats }) {
  try {
    const rrcLogs = logs.filter(log => 
      log.protocol === 'RRC' || log.component === 'RRC'
    );
    
    const rrcStats = React.useMemo(() => {
      let connectionSetups = 0;
      let connectionReleases = 0;
      let reconfigurations = 0;
      let measurementReports = 0;
      let handovers = 0;
      let failures = 0;
      
      rrcLogs.forEach(log => {
        const msg = log.message.toLowerCase();
        if (msg.includes('connection setup') || msg.includes('setup request')) connectionSetups++;
        if (msg.includes('connection release') || msg.includes('release')) connectionReleases++;
        if (msg.includes('reconfiguration')) reconfigurations++;
        if (msg.includes('measurement report')) measurementReports++;
        if (msg.includes('handover')) handovers++;
        if (msg.includes('failure') || msg.includes('error')) failures++;
      });
      
      return {
        connectionSetups,
        connectionReleases,
        reconfigurations,
        measurementReports,
        handovers,
        successRate: connectionSetups > 0 ? 
          (((connectionSetups - failures) / connectionSetups) * 100).toFixed(1) : '100',
        totalMessages: rrcLogs.length
      };
    }, [rrcLogs]);
    
    return React.createElement('div', {
      className: 'p-6 space-y-6',
      'data-name': 'rrc-stats',
      'data-file': 'components/layers/RRCStats.js'
    }, [
      React.createElement('div', {
        key: 'header',
        className: 'flex items-center justify-between'
      }, [
        React.createElement('h1', {
          key: 'title',
          className: 'text-2xl font-bold text-gray-900 flex items-center'
        }, [
          React.createElement('i', {
            key: 'icon',
            'data-lucide': 'settings',
            className: 'w-6 h-6 text-red-600 mr-3'
          }),
          'RRC Layer Analysis'
        ]),
        React.createElement('span', {
          key: 'count',
          className: 'text-sm text-gray-600'
        }, `${rrcStats.totalMessages} messages`)
      ]),
      
      React.createElement('div', {
        key: 'metrics',
        className: 'grid grid-cols-2 md:grid-cols-4 gap-6'
      }, [
        React.createElement('div', {
          key: 'setups',
          className: 'bg-white rounded-lg shadow p-6'
        }, [
          React.createElement('div', {
            key: 'content',
            className: 'flex items-center justify-between'
          }, [
            React.createElement('div', { key: 'data' }, [
              React.createElement('p', {
                key: 'label',
                className: 'text-sm font-medium text-gray-600'
              }, 'Connection Setups'),
              React.createElement('p', {
                key: 'value',
                className: 'text-2xl font-bold text-green-600'
              }, rrcStats.connectionSetups)
            ]),
            React.createElement('i', {
              key: 'icon',
              'data-lucide': 'link',
              className: 'w-6 h-6 text-green-600'
            })
          ])
        ]),
        React.createElement('div', {
          key: 'reconfigs',
          className: 'bg-white rounded-lg shadow p-6'
        }, [
          React.createElement('div', {
            key: 'content',
            className: 'flex items-center justify-between'
          }, [
            React.createElement('div', { key: 'data' }, [
              React.createElement('p', {
                key: 'label',
                className: 'text-sm font-medium text-gray-600'
              }, 'Reconfigurations'),
              React.createElement('p', {
                key: 'value',
                className: 'text-2xl font-bold text-blue-600'
              }, rrcStats.reconfigurations)
            ]),
            React.createElement('i', {
              key: 'icon',
              'data-lucide': 'refresh-cw',
              className: 'w-6 h-6 text-blue-600'
            })
          ])
        ]),
        React.createElement('div', {
          key: 'success',
          className: 'bg-white rounded-lg shadow p-6'
        }, [
          React.createElement('div', {
            key: 'content',
            className: 'flex items-center justify-between'
          }, [
            React.createElement('div', { key: 'data' }, [
              React.createElement('p', {
                key: 'label',
                className: 'text-sm font-medium text-gray-600'
              }, 'Success Rate'),
              React.createElement('p', {
                key: 'value',
                className: 'text-2xl font-bold text-purple-600'
              }, `${rrcStats.successRate}%`)
            ]),
            React.createElement('i', {
              key: 'icon',
              'data-lucide': 'check-circle',
              className: 'w-6 h-6 text-purple-600'
            })
          ])
        ]),
        React.createElement('div', {
          key: 'handovers',
          className: 'bg-white rounded-lg shadow p-6'
        }, [
          React.createElement('div', {
            key: 'content',
            className: 'flex items-center justify-between'
          }, [
            React.createElement('div', { key: 'data' }, [
              React.createElement('p', {
                key: 'label',
                className: 'text-sm font-medium text-gray-600'
              }, 'Handovers'),
              React.createElement('p', {
                key: 'value',
                className: 'text-2xl font-bold text-orange-600'
              }, rrcStats.handovers)
            ]),
            React.createElement('i', {
              key: 'icon',
              'data-lucide': 'repeat',
              className: 'w-6 h-6 text-orange-600'
            })
          ])
        ])
      ])
    ]);

  } catch (error) {
    console.error('RRCStats component error:', error);
    reportError(error);
    return React.createElement('div', {
      className: 'text-red-600 p-4'
    }, 'RRCStats Error');
  }
}

// Export RRCStats component
window.RRCStats = RRCStats;
